# References

This directory contains additional documentation and reference materials for the file-analysis skill.

## File Organization Patterns

Common file organization patterns across different frameworks and project types.

## Metadata Extraction

Methods for extracting metadata from various file formats and frontmatter conventions.
