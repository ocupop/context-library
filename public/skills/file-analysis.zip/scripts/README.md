# Scripts

This directory contains executable scripts that can be used by agents when performing file analysis tasks.

Scripts should be self-contained or clearly document their dependencies.
