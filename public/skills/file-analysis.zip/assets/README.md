# Assets

This directory contains static resources such as templates, diagrams, or example files related to file analysis.
